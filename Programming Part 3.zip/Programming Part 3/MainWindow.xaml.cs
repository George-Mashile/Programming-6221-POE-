﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Programming_Part_3
{
    public partial class MainWindow : Window
    {
        // Activity Log
        private List<string> activityLog = new List<string>();

        //  Tasks 
        private List<CyberTask> tasks = new List<CyberTask>();

        //  Quiz 
        private int quizIndex = 0;
        private int quizScore = 0;
        private List<QuizQuestion> questions;
        private bool quizActive = false;

        //  NLP keyword maps 
        private Dictionary<string[], string> nlpResponses;

        public MainWindow()
        {
            InitializeComponent();
            BuildNlpMap();
            BuildQuestions();
            AddBotMessage(" Hello! I'm your CyberWorks Awareness Chatbot.\n\n" +
                          "I can help you with:\n" +
                          " Managing cybersecurity tasks\n" +
                          " Testing your knowledge with a quiz\n" +
                          " Answering security questions\n" +
                          " Tracking your activity\n\n" +
                          "Type a message or use the sidebar to navigate!");
        }

        //  NAV
        
        private void HideAll()
        {
            PanelChat.Visibility = Visibility.Collapsed;
            PanelTask.Visibility = Visibility.Collapsed;
            PanelQuiz.Visibility = Visibility.Collapsed;
            PanelLog.Visibility = Visibility.Collapsed;
        }

        private void ShowChat(object s, RoutedEventArgs e) { HideAll(); PanelChat.Visibility = Visibility.Visible; }
        private void ShowTasks(object s, RoutedEventArgs e) { HideAll(); PanelTask.Visibility = Visibility.Visible; RefreshTaskList(); }
        private void ShowQuiz(object s, RoutedEventArgs e) { HideAll(); PanelQuiz.Visibility = Visibility.Visible; }
        private void ShowLog(object s, RoutedEventArgs e) { HideAll(); PanelLog.Visibility = Visibility.Visible; RefreshLog(); }

        //  CHAT & NLP
        private void BuildNlpMap()
        {
            nlpResponses = new Dictionary<string[], string>(new KeyArrayComparer())
            {
                { new[]{"hello","hi","hey","greetings"},
                  "Hello! How can I assist you with cybersecurity today?" },

                { new[]{"password","passwd","credentials"},
                  " Password Tip: Use at least 12 characters with uppercase, lowercase, numbers & symbols. Never reuse passwords!" },

                { new[]{"phishing","scam","fake email","suspicious email"},
                  " Phishing Alert: Never click unknown links. Verify sender addresses. Report suspicious emails!" },

                { new[]{"2fa","two factor","two-factor","mfa","multi factor"},
                  " Two-Factor Authentication adds an extra security layer. Enable it on all important accounts!" },

                { new[]{"task","add task","remind","reminder","set reminder"},
                  " Switch to the Task Assistant tab to add and manage your cybersecurity tasks!" },

                { new[]{"quiz","game","test","challenge"},
                  " Head to the Mini Quiz tab to test your cybersecurity knowledge!" },

                { new[]{"log","activity","history","what have you done"},
                  " Check the Activity Log tab to see a summary of recent actions!" },

                { new[]{"vpn","virtual private"},
                  " VPNs encrypt your internet traffic. Always use a trusted VPN on public Wi-Fi!" },

                { new[]{"malware","virus","ransomware","spyware"},
                  " Keep your antivirus updated and avoid downloading files from unknown sources!" },

                { new[]{"firewall"},
                  " Firewalls monitor network traffic. Ensure your OS firewall is always enabled!" },

                { new[]{"backup","back up"},
                  " Follow the 3-2-1 backup rule: 3 copies, 2 media types, 1 offsite location!" },

                { new[]{"update","patch","upgrade"},
                  " Always keep your software updated to protect against known vulnerabilities!" },

                { new[]{"safe browsing","https","ssl"},
                  " Only browse sites with HTTPS. Avoid entering sensitive data on HTTP sites!" },

                { new[]{"social engineering","manipulation"},
                  " Social engineering tricks people into revealing info. Always verify identities before sharing data!" },

                { new[]{"help","what can you do"},
                  "I can help with:\n• Cybersecurity tips\n• Task management\n• Quiz game\n• Activity logging\n\nJust type your question!" },
            };
        }

        private string GetNlpResponse(string input)
        {
            input = input.ToLower().Trim();

            foreach (var kvp in nlpResponses)
            {
                if (kvp.Key.Any(k => input.Contains(k)))
                    return kvp.Value;
            }

            // Detect task-add intent via NLP
            if ((input.Contains("add") || input.Contains("create") || input.Contains("new")) &&
                (input.Contains("task") || input.Contains("todo") || input.Contains("reminder")))
            {
                return " It sounds like you want to add a task! Head to the Task Assistant tab to get started.";
            }

            return " I didn't quite understand that. Could you rephrase? Try asking about passwords, phishing, 2FA, tasks, or the quiz!";
        }

        private void SendMessage(object s, RoutedEventArgs e)
        {
            string msg = ChatInput.Text.Trim();
            if (string.IsNullOrEmpty(msg) || msg == " ") return;

            AddUserMessage(msg);
            ChatInput.Clear();

            string response = GetNlpResponse(msg);
            AddBotMessage(response);

            LogAction($"Chat NLP response triggered for: \"{msg}\"");
        }

        private void ChatInput_KeyDown(object s, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) SendMessage(s, null);
        }

        //  Message Bubble Helpers 
        private void AddUserMessage(string text)
        {
            var border = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(46, 46, 78)),
                CornerRadius = new CornerRadius(10, 10, 2, 10),
                Padding = new Thickness(12, 8, 12, 8),
                Margin = new Thickness(80, 5, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            border.Child = new TextBlock
            {
                Text = text,
                Foreground = Brushes.White,
                FontSize = 13,
                TextWrapping = TextWrapping.Wrap
            };
            ChatPanel.Children.Add(border);
            ChatScroll.ScrollToBottom();
        }

        private void AddBotMessage(string text)
        {
            var wrap = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 80, 5) };
            var icon = new TextBlock { Text = "", FontSize = 20, Margin = new Thickness(0, 0, 8, 0), VerticalAlignment = VerticalAlignment.Top };
            var border = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(135,206,235)),
                CornerRadius = new CornerRadius(10, 10, 10, 2),
                Padding = new Thickness(12, 8, 12, 8),
                MaxWidth = 620
            };
            border.Child = new TextBlock
            {
                Text = text,
                Foreground = Brushes.White,
                FontSize = 13,
                TextWrapping = TextWrapping.Wrap
            };
            wrap.Children.Add(icon);
            wrap.Children.Add(border);
            ChatPanel.Children.Add(wrap);
            ChatScroll.ScrollToBottom();
        }

        //  TASK ASSISTANT
        private void AddTask(object s, RoutedEventArgs e)
        {
            string title = TaskTitle.Text.Trim();
            string desc = TaskDesc.Text.Trim();
            string reminder = TaskReminder.Text.Trim();

            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Please enter a task title.", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var task = new CyberTask
            {
                Id = Guid.NewGuid().ToString("N").Substring(0, 6).ToUpper(),
                Title = title,
                Description = string.IsNullOrEmpty(desc) ? $"Complete: {title}" : desc,
                Reminder = reminder,
                CreatedAt = DateTime.Now,
                IsCompleted = false
            };

            tasks.Add(task);

            string logEntry = $"Task added: '{title}'" + (string.IsNullOrEmpty(reminder) ? "" : $" | Reminder: {reminder}");
            LogAction(logEntry);

            TaskTitle.Clear();
            TaskDesc.Clear();
            TaskReminder.Clear();

            RefreshTaskList();
            AddBotMessage($" Task added: '{title}'. " +
                          (string.IsNullOrEmpty(reminder)
                            ? "No reminder set."
                            : $"I'll remind you in: {reminder}."));
        }

        private void RefreshTaskList()
        {
            TaskListPanel.Children.Clear();

            if (tasks.Count == 0)
            {
                TaskListPanel.Children.Add(new TextBlock
                {
                    Text = "No tasks yet. Add your first cybersecurity task above!",
                    Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255)),
                    FontSize = 13,
                    Margin = new Thickness(5, 10, 0, 0)
                });
                return;
            }

            foreach (var task in tasks.ToList())
            {
                var card = new Border
                {
                    Background = task.IsCompleted
                        ? new SolidColorBrush(Color.FromRgb(20, 40, 20))
                        : new SolidColorBrush(Color.FromRgb(26, 26, 48)),
                    CornerRadius = new CornerRadius(10),
                    Padding = new Thickness(15, 12, 15, 12),
                    Margin = new Thickness(0, 0, 0, 10)
                };

                var grid = new Grid();
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var info = new StackPanel();
                info.Children.Add(new TextBlock
                {
                    Text = $"[{task.Id}] {task.Title}" + (task.IsCompleted ? "   Completed" : ""),
                    Foreground = task.IsCompleted ? Brushes.LightGreen : Brushes.White,
                    FontSize = 14,
                    FontWeight = FontWeights.Bold
                });
                info.Children.Add(new TextBlock
                {
                    Text = task.Description,
                    Foreground = new SolidColorBrush(Color.FromRgb(170, 170, 200)),
                    FontSize = 12,
                    Margin = new Thickness(0, 3, 0, 0)
                });
                if (!string.IsNullOrEmpty(task.Reminder))
                {
                    info.Children.Add(new TextBlock
                    {
                        Text = $" Reminder: {task.Reminder}",
                        Foreground = new SolidColorBrush(Color.FromRgb(255, 215, 0)),
                        FontSize = 11,
                        Margin = new Thickness(0, 3, 0, 0)
                    });
                }
                info.Children.Add(new TextBlock
                {
                    Text = $"Added: {task.CreatedAt:dd MMM yyyy HH:mm}",
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 120)),
                    FontSize = 10,
                    Margin = new Thickness(0, 3, 0, 0)
                });

                Grid.SetColumn(info, 0);
                grid.Children.Add(info);

                var btns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

                if (!task.IsCompleted)
                {
                    var completeBtn = new Button
                    {
                        Content = " Done",
                        Background = new SolidColorBrush(Color.FromRgb(30, 120, 30)),
                        Foreground = Brushes.White,
                        BorderThickness = new Thickness(0),
                        Padding = new Thickness(10, 5, 10, 5),
                        Margin = new Thickness(0, 0, 6, 0),
                        Cursor = Cursors.Hand,
                        Tag = task.Id
                    };
                    completeBtn.Click += CompleteTask;
                    btns.Children.Add(completeBtn);
                }

                var deleteBtn = new Button
                {
                    Content = " Delete",
                    Background = new SolidColorBrush(Color.FromRgb(150, 30, 30)),
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(0),
                    Padding = new Thickness(10, 5, 10, 5),
                    Cursor = Cursors.Hand,
                    Tag = task.Id
                };
                deleteBtn.Click += DeleteTask;
                btns.Children.Add(deleteBtn);

                Grid.SetColumn(btns, 1);
                grid.Children.Add(btns);

                card.Child = grid;
                TaskListPanel.Children.Add(card);
            }
        }

        private void CompleteTask(object s, RoutedEventArgs e)
        {
            string id = (s as Button)?.Tag?.ToString();
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                task.IsCompleted = true;
                LogAction($"Task completed: '{task.Title}'");
                RefreshTaskList();
            }
        }

        private void DeleteTask(object s, RoutedEventArgs e)
        {
            string id = (s as Button)?.Tag?.ToString();
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                LogAction($"Task deleted: '{task.Title}'");
                tasks.Remove(task);
                RefreshTaskList();
            }
        }

        //  QUIZ
        private void BuildQuestions()
        {
            questions = new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What should you do if you receive an email asking for your password?",
                    Options = new[] { "A) Reply with your password", "B) Delete the email", "C) Report the email as phishing", "D) Ignore it" },
                    CorrectIndex = 2,
                    Explanation = "Correct! "
                },
                new QuizQuestion
                {
                    Question = "Which is the STRONGEST password?",
                    Options = new[] { "A) password123", "B) MyDog2020", "C) Tr0ub4dor&3!", "D) 12345678" },
                    CorrectIndex = 2,
                    Explanation = "Correct! "
                },
                new QuizQuestion
                {
                    Question = "True or False: Public Wi-Fi is safe for online banking.",
                    Options = new[] { "A) True", "B) False" },
                    CorrectIndex = 1,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "What does 2FA stand for?",
                    Options = new[] { "A) Two-File Authentication", "B) Two-Factor Authentication", "C) Two-Form Authorization", "D) Twice-Failed Attempt" },
                    CorrectIndex = 1,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "Which of these is a sign of a phishing website?",
                    Options = new[] { "A) HTTPS in the URL", "B) A padlock icon", "C) Misspelled domain names", "D) A privacy policy" },
                    CorrectIndex = 2,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "How often should you update your passwords?",
                    Options = new[] { "A) Never", "B) Every 5 years", "C) Every 6-12 months", "D) Only when hacked" },
                    CorrectIndex = 2,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "True or False: Antivirus software makes you 100% safe.",
                    Options = new[] { "A) True", "B) False" },
                    CorrectIndex = 0,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "What is 'social engineering' in cybersecurity?",
                    Options = new[] { "A) Hacking servers", "B) Tricking people to reveal info", "C) Building social networks", "D) Installing malware remotely" },
                    CorrectIndex = 1,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "Which is the safest way to store passwords?",
                    Options = new[] { "A) In a text file on your desktop", "B) In your email drafts", "C) In a password manager", "D) On a sticky note" },
                    CorrectIndex = 2,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "True or False: You should click 'Unsubscribe' in spam emails.",
                    Options = new[] { "A) True", "B) False" },
                    CorrectIndex = 1,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "What does HTTPS indicate about a website?",
                    Options = new[] { "A) It is government owned", "B) Data is encrypted in transit", "C) It is free to use", "D) It has no ads" },
                    CorrectIndex = 1,
                    Explanation = "Correct!"
                },
                new QuizQuestion
                {
                    Question = "What is ransomware?",
                    Options = new[] { "A) Software that speeds up your PC", "B) Malware that encrypts files and demands payment", "C) A type of antivirus", "D) A firewall tool" },
                    CorrectIndex = 1,
                    Explanation = "Correct!"
                },
            };
        }

        private void StartQuiz(object s, RoutedEventArgs e)
        {
            quizIndex = 0;
            quizScore = 0;
            quizActive = true;
            ScoreLabel.Text = "Score: 0";
            StartQuizBtn.Content = " Restart";
            FeedbackText.Text = "Choose an answer above!";
            LogAction("Quiz started.");
            ShowQuestion();
        }

        private void ShowQuestion()
        {
            QuizArea.Children.Clear();

            if (quizIndex >= questions.Count)
            {
                EndQuiz();
                return;
            }

            var q = questions[quizIndex];
            QuizProgress.Text = $"Question {quizIndex + 1} of {questions.Count}";

            QuizArea.Children.Add(new TextBlock
            {
                Text = q.Question,
                Foreground = Brushes.White,
                FontSize = 15,
                FontWeight = FontWeights.Bold,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 15)
            });

            for (int i = 0; i < q.Options.Length; i++)
            {
                int idx = i;
                var btn = new Button
                {
                    Content = q.Options[i],
                    Background = new SolidColorBrush(Color.FromRgb(46, 46, 78)),
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(0),
                    Padding = new Thickness(14, 10, 14, 10),
                    Margin = new Thickness(0, 4, 0, 4),
                    HorizontalContentAlignment = HorizontalAlignment.Left,
                    Cursor = Cursors.Hand,
                    FontSize = 13
                };
                btn.Click += (ss, ee) => AnswerQuestion(idx, q);
                QuizArea.Children.Add(btn);
            }
        }

        private void AnswerQuestion(int chosen, QuizQuestion q)
        {
            // Disable all buttons
            foreach (var child in QuizArea.Children)
            {
                if (child is Button b) b.IsEnabled = false;
            }

            bool correct = chosen == q.CorrectIndex;
            if (correct)
            {
                quizScore++;
                ScoreLabel.Text = $"Score: {quizScore}";
                FeedbackText.Text = q.Explanation;
                FeedbackText.Foreground = Brushes.LightGreen;
            }
            else
            {
                FeedbackText.Text = $" Incorrect! ";
                FeedbackText.Foreground = new SolidColorBrush(Color.FromRgb(255, 100, 100));
            }

            // Highlight correct
            int btnIdx = 0;
            foreach (var child in QuizArea.Children)
            {
                if (child is Button b2)
                {
                    if (btnIdx == q.CorrectIndex)
                        b2.Background = new SolidColorBrush(Color.FromRgb(30, 120, 30));
                    else if (btnIdx == chosen && !correct)
                        b2.Background = new SolidColorBrush(Color.FromRgb(140, 30, 30));
                    btnIdx++;
                }
            }

            // Next question after short delay via DispatcherTimer
            var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            timer.Tick += (s, e) => { timer.Stop(); quizIndex++; ShowQuestion(); };
            timer.Start();
        }

        private void EndQuiz()
        {
            quizActive = false;
            QuizProgress.Text = "Quiz Complete!";
            QuizArea.Children.Clear();
            Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));

            string feedback = quizScore >= 10 ? " Outstanding! You're a cybersecurity pro!" :
                              quizScore >= 7 ? " Great job! Keep learning to stay safe!" :
                              quizScore >= 4 ? " Good effort! Review the topics and try again." :
                                               " Keep learning to stay safe online!";

            QuizArea.Children.Add(new TextBlock
            {
                Text = $" Quiz Complete!\n\nYour Score: {quizScore} / {questions.Count}\n\n",
                FontSize = 16,
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 28
            });

            FeedbackText.Text = feedback;
            FeedbackText.Foreground = Brushes.LightGreen;
            LogAction($"Quiz completed. Score: {quizScore}/{questions.Count}.");
        }

        //  ACTIVITY LOG
        private void LogAction(string description)
        {
            string entry = $"[{DateTime.Now:HH:mm:ss}] {description}";
            activityLog.Insert(0, entry);
            if (activityLog.Count > 50) activityLog.RemoveAt(activityLog.Count - 1);
        }

        private void RefreshLog()
        {
            LogPanel.Children.Clear();
            var recent = activityLog.Take(10).ToList();

            if (recent.Count == 0)
            {
                LogPanel.Children.Add(new TextBlock
                {
                    Text = "No activity recorded yet. Start chatting, add tasks, or take the quiz!",
                    Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255)),
                    FontSize = 13,
                    Margin = new Thickness(5, 10, 0, 0)
                });
                return;
            }

            int num = 1;
            foreach (var entry in recent)
            {
                var row = new Border
                {
                    Background = new SolidColorBrush(Color.FromRgb(26, 26, 48)),
                    CornerRadius = new CornerRadius(8),
                    Padding = new Thickness(12, 8, 12, 8),
                    Margin = new Thickness(0, 0, 0, 6)
                };
                row.Child = new TextBlock
                {
                    Text = $"{num++}. {entry}",
                    Foreground = new SolidColorBrush(Color.FromRgb(200, 200, 220)),
                    FontSize = 12,
                    TextWrapping = TextWrapping.Wrap
                };
                LogPanel.Children.Add(row);
            }
        }

        private void ClearLog(object s, RoutedEventArgs e)
        {
            activityLog.Clear();
            RefreshLog();
        }
    }

    //  MODELS
    public class CyberTask
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Reminder { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsCompleted { get; set; }
    }

    public class QuizQuestion
    {
        public string Question { get; set; }
        public string[] Options { get; set; }
        public int CorrectIndex { get; set; }
        public string Explanation { get; set; }
    }

    // NLP dictionary comparer (allows array keys)
    public class KeyArrayComparer : IEqualityComparer<string[]>
    {
        public bool Equals(string[] x, string[] y) => x.SequenceEqual(y);
        public int GetHashCode(string[] obj) => obj.Aggregate(0, (h, s) => h ^ s.GetHashCode());
    }
}